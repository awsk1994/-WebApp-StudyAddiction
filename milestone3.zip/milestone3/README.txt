Some redundant methods but it works!

A0: Server-side: 
Can create user, get list of user, get user information and update user info (although updating it is not a functionality of client-side).

B0: Client-side:
At http://localhost:3000: user has option to sign up or sign in.

B1: Sign up:
 - POST method to server-side, and upon submission, directly log in.
 - empty password is ok.
 - USERNAME must be entered.
 - If server-side has the same username, it will bounce back error.

B2: Sign-In:
 - Verify password based on username from server-side.
 - If verified, will direct to signed-in page.
 - For security reasons, signin.html does not actually sign you in, but rather, puts validates it and puts it into local storage. SignedIn page will do another verification.

B3: SignedIn:
This is the actual verification to prevent users to hack in. 
 - verification process is based on data in localStorage (which should be updated in sign in page)
 - upon verified, will retrieve and display user info from server-side.
 - Log out button will clear localStorage (thus, will need to log in again if want to sign in)

TESTS:
Sign Up -> Sign out -> Sign in 									:: OK

Sign In with wrong username/password -> REJECTED				:: OK
Sign In with correct username/password -> ACCEPTED				:: OK

Signed In -> use another browser -> need to sign in again 		:: OK
Signed In -> open signedIn page with another tab -> ACCEPTED	:: OK
Signed In -> open sign-in page with another tab -> redirected to signed in :: OK


